export const Test_API = 'http://192.168.29.250:10500/api/v1/';

export const Img_Url = 'http://192.168.29.250:10500/'