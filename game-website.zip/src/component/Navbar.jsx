import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";

export default function Navbar() {
    const location = useLocation();
    const [coins, setCoins] = useState(() => {
        // Initialize coins from session storage or location state
        const initialCoins = parseInt(location.state?.coins || sessionStorage.getItem("coins"), 10) || 0;
        return initialCoins;
    });

    // Update coins when location state changes
    useEffect(() => {
        const updatedCoins = parseInt(location.state?.coins || sessionStorage.getItem("coins"), 10) || 0;
        setCoins(updatedCoins);
    }, [location.state]);

    // Store coins in session storage whenever they change
    useEffect(() => {
        if (coins > 0) {
            sessionStorage.setItem("coins", coins);
        }
    }, [coins]);

    // Clear coins from session storage if needed
    const clearCoins = () => {
        sessionStorage.removeItem("coins");
        setCoins(0);
    };

    // Check if the current path matches specific routes
    const isSpecialRoute =
        location.pathname === "/tournament" ||
        location.pathname === "/stories" ||
        location.pathname === "/game";

    return (
        <div>
            {isSpecialRoute ? (
                // Navbar for special routes
                <div className="bg-white py-4 navigationbar">
                    <div className="d-flex justify-content-between">
                        <div>
                            <Link to="/" className="logo">GamecWebs</Link>
                        </div>
                        <div className="navbar-coins px-5 py-2 d-flex align-items-center">
                            <span className="me-2">{coins} coins</span>
                            <img src="/img/coins-ic.svg" alt="coins-icon" className="img-fluid" />
                        </div>
                    </div>
                </div>
            ) : (
                // Navbar for default routes
                <div className="bg-white py-4 navigationbar">
                    <div className="d-flex justify-content-between">
                        <div>
                            <Link to="/" className="logo">GamecWebs</Link>
                        </div>
                        <div>
                            <img src="/img/day-mode-ic.svg" alt="day-mode-icon" className="img-fluid" />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
